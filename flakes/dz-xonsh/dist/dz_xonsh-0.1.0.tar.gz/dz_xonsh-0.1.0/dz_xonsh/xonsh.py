import xonsh.main

def main:
    xonsh.main.main()
